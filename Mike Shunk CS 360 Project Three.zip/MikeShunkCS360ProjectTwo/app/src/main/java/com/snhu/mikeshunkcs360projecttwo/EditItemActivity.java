// Mike Shunk
// SNHU CS 360
// June 16, 2022
// Project Three
// EditItemActivity.java
// This class creates the layout for our "edit item" screen and handles clicks on
// the "update" button.

package com.snhu.mikeshunkcs360projecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class EditItemActivity extends AppCompatActivity {

    // Views for the fields of the screen
    EditText itemName;
    EditText itemSku;
    EditText itemQty;
    EditText itemLoc;
    TextView errorText;
    Button button;

    // Stores the prior SKU and quantity values for use in other functions
    String oldSku;
    String oldQty;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);
        Intent intent = getIntent();

        // Gets an array list with data on the item clicked on
        ArrayList<String> item = intent.getStringArrayListExtra("item");

        itemName = findViewById(R.id.editTextItemName);
        itemSku = findViewById(R.id.editTextSku);
        itemQty = findViewById(R.id.editTextItemQuantity);
        itemLoc = findViewById(R.id.editTextItemLocation);
        button = findViewById(R.id.addButton);

        // Fill out the fields with the current values
        itemName.setText(item.get(0));
        itemSku.setText(item.get(1));
        itemQty.setText(item.get(2));
        itemLoc.setText(item.get(3));
        button.setText("Update");

        oldSku = item.get(1);
        oldQty = item.get(2);
    }

    // Called when a user clicks "Update"
    public void onClick(View view) {
        // An array list for storing item data
        ArrayList<String> item = new ArrayList<>();
        errorText =  findViewById(R.id.errorAddItem);

        // Gets text from the views
        String name = itemName.getText().toString();
        String sku = itemSku.getText().toString();
        String qty = itemQty.getText().toString();
        String loc = itemLoc.getText().toString();

        // If any of the fields are empty, display an error message
        if(name.matches("") || sku.matches("") || qty.matches("") || loc.matches("") ) {
            errorText.setText("Please fill out all fields!");
        }
        else {
            item.add(name);
            item.add(sku);
            item.add(qty);
            item.add(loc);
            item.add(oldSku);
            item.add(oldQty);
            // Return to GridActivity and return an array list with our item attributes
            Intent intent = new Intent();
            intent.putExtra("edit_item", item);
            setResult(RESULT_OK, intent);
            this.finish();
        }

    }


}
