// Mike Shunk
// SNHU CS 360
// June 16, 2022
// Project Three
// AlertDatabase.java
// This class creates a database for storing alerts and provides methods to add/delete alerts,
// as well as a method to return all alerts.
package com.snhu.mikeshunkcs360projecttwo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;

public class AlertDatabase extends SQLiteOpenHelper {

    private static AlertDatabase instance; // Stores an instance of the database
    private static final String DATABASE_NAME = "alerts.db";
    private static final int VERSION = 2;

    // Singleton to ensure only one copy of the database exists
    public static synchronized AlertDatabase getInstance(Context context){
        if(instance == null) {
            instance = new AlertDatabase(context);
        }
        return instance;
    }

    // Constructor
    public AlertDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    // Schema for our table
    private static final class AlertTable {
        private static final String TABLE = "alert";
        private static final String COL_NAME = "name";
        private static final String COL_SKU = "sku";
        private static final String COL_QTY = "quantity";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + AlertTable.TABLE + " (" + AlertTable.COL_NAME + " text, " + AlertTable.COL_SKU + " text, " + AlertTable.COL_QTY + " text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + AlertTable.TABLE);
        onCreate(db);
    }

    // Add a new alert
    public void addAlerts(String name, String sku, String qty) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(AlertTable.COL_NAME, name);
        values.put(AlertTable.COL_SKU, sku);
        values.put(AlertTable.COL_QTY, qty);
        db.insert(AlertTable.TABLE, null, values);
    }

    // Remove an alert
    public void deleteAlert(String sku) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(AlertDatabase.AlertTable.TABLE, "sku=?",
                new String[] { sku });
        db.close();
    }

    // Get all of the alerts in the database
    public ArrayList<String> getAllAlerts() {
        String tempAlert; // Holds the current alert in the loop
        ArrayList<String> alerts = new ArrayList<>(); // An array list of alerts to be returned
        SQLiteDatabase db = getReadableDatabase();

        String query = "select * from " + AlertTable.TABLE; // Gets all rows
        Cursor cursor = db.rawQuery(query, null);

        // Loops through each row of the database, adds the data to a formatted string, then
        // adds the string to the array list
        if (cursor.moveToFirst()) {
            do {
                tempAlert = cursor.getString(0) + " SKU: " + cursor.getString(1)
                        + " is running low and " + cursor.getString(2) + " unit(s) remain\n\n";
                alerts.add(tempAlert);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return alerts;
    }
}
