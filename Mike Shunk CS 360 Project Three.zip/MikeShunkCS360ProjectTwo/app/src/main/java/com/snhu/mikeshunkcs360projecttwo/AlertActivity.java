// Mike Shunk
// SNHU CS 360
// June 16, 2022
// Project Three
// AlertActivity.java
// This class creates the layout for our alerts screen and displays the alerts
package com.snhu.mikeshunkcs360projecttwo;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.os.Bundle;
import android.widget.TextView;
import java.util.ArrayList;

public class AlertActivity extends AppCompatActivity {

    TextView alertBody; // View where the alerts are displayed
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alert);
        context = getApplicationContext();

        // Get the current instance of the alert database
        AlertDatabase db = AlertDatabase.getInstance(context);

        // Get all of the alerts from the database
        ArrayList<String> alerts = db.getAllAlerts();

        String alertText = ""; // The text to be printed in our text view

        // Concatenate each alert onto a string
        for(int i = 0; i < alerts.size(); ++i) {
            alertText = alertText + alerts.get(i);
        }

        // Set the above string as the text for our view
        alertBody = findViewById(R.id.alerts);
        alertBody.setText(alertText);
    }
}