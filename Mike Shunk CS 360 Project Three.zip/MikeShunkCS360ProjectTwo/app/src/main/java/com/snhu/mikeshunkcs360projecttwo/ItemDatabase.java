// Mike Shunk
// SNHU CS 360
// June 16, 2022
// Project Three
// ItemDatabase.java
// This class creates a database for storing inventory items and provides methods to add, delete,
// and update items, return all items, and send an SMS message regarding low item quantities
package com.snhu.mikeshunkcs360projecttwo;

import android.Manifest;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.telephony.SmsManager;
import androidx.core.content.ContextCompat;
import java.util.ArrayList;

public class ItemDatabase extends SQLiteOpenHelper {

    Context context;
    // Attributes of our database
    private static final String DATABASE_NAME = "inventory.db";
    private static final int VERSION = 2;
    AlertDatabase alertDatabase;

    // Constructor
    public ItemDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
        this.context = context;
        // Gets an instance of the alert database
        this.alertDatabase = AlertDatabase.getInstance(context);
    }

    // Schema for our table
    private static final class ItemTable {
        private static final String TABLE = "inventory";
        private static final String COL_NAME = "item_name";
        private static final String COL_SKU = "sku";
        private static final String COL_QTY = "quantity";
        private static final String COL_LOC = "location";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + ItemTable.TABLE + " (" + ItemTable.COL_NAME + " text, " + ItemTable.COL_SKU + " text, " + ItemTable.COL_QTY + " text, " + ItemTable.COL_LOC + " text)" );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + ItemTable.TABLE);
        onCreate(db);
    }

    // Add a new item to the database
    public void addItem(String name, int sku, int qty, String loc) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(ItemTable.COL_NAME, name);
        values.put(ItemTable.COL_SKU, String.valueOf(sku));
        values.put(ItemTable.COL_QTY, String.valueOf(qty));
        values.put(ItemTable.COL_LOC, loc);

        db.insert(ItemTable.TABLE, null, values);
        db.close();
    }

    // Remove an item from our database with a given SKU
    public void deleteItem(String sku) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(ItemTable.TABLE, "sku=?",
                new String[] { sku });
        db.close();

        // Delete any alerts that may exist for this item
        alertDatabase.deleteAlert(sku);
    }

    // Update an item in our database
    public void updateItem(ArrayList<String> editItem ) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(ItemTable.COL_NAME, editItem.get(0));
        values.put(ItemTable.COL_SKU, editItem.get(1));
        values.put(ItemTable.COL_QTY, editItem.get(2));
        values.put(ItemTable.COL_LOC, editItem.get(3));

        // Updates the item using the old SKU variable in case the user updated the SKU
        db.update(ItemTable.TABLE, values, "sku = ?", new String[] { editItem.get(4) });

        // If the item's quantity drops below three, create an alert string for that item and
        // add it to the database of alerts
        if(Integer.parseInt(editItem.get(2)) < 3) {
            String tempAlert = editItem.get(0) + " SKU: " + editItem.get(1)
                    + " is running low and " + editItem.get(2) + " unit(s) remain";

            alertDatabase.addAlerts(editItem.get(0),editItem.get(1),editItem.get(2));

            // If the user has granted permission to send SMS messages, call our method
            // to send an SMS with the given alert string
            if(ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_DENIED) {
                sendSMS(tempAlert);
            }
        }

        // If the previous quantity was less than three and has been updated to three or more,
        // remove the alert for that item from the alert database
        if(Integer.parseInt(editItem.get(5)) < 3 && Integer.parseInt(editItem.get(2)) > 2) {
            alertDatabase.deleteAlert(editItem.get(1));
        }
        db.close();
    }

    // Returns an array list of all items in the database
    public ArrayList<Item> getAllItems() {
        // Temporary values for item attributes
        Item tempItem;
        String tempName;
        String tempSKU;
        String tempQty;
        String tempLoc;
        // An array list to store all of our items
        ArrayList<Item> items = new ArrayList<>();

        SQLiteDatabase db = getReadableDatabase();
        // Retrieves all rows in the table
        String query = "select * from " + ItemTable.TABLE;
        Cursor cursor = db.rawQuery(query, null);

        // Loop through each item in the database and add it to our array list
        if(cursor.moveToFirst()) {
            do {
                tempName = cursor.getString(0);
                tempSKU = cursor.getString(1);
                tempQty = cursor.getString(2);
                tempLoc = cursor.getString(3);
                tempItem = new Item(tempName, Integer.parseInt(tempSKU), Integer.parseInt(tempQty), tempLoc);

                items.add(tempItem);
            } while(cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return items;
    }

    // Sends an SMS message with a low inventory alert
    // Currently set to message the emulated device the app is running on since it does not
    // have a SIM card and cannot send messages to other phones
    public void sendSMS(String alert) {
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage("+1-555-521-5554",null,alert,null,null);
    }
}
