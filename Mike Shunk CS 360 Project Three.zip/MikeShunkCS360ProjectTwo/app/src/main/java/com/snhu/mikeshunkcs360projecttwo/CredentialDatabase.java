// Mike Shunk
// SNHU CS 360
// June 16, 2022
// Project Three
// CredentialDatabase.java
// This class creates a database for storing login credentials and provides methods to add a user
// as well as retrieve their password.
package com.snhu.mikeshunkcs360projecttwo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class CredentialDatabase extends SQLiteOpenHelper {

    // Attributes of our database
    private static final String DATABASE_NAME = "credentials.db";
    private static final int VERSION = 2;

    // Constructor
    public CredentialDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    // Schema for our table
    private static final class CredentialTable {
        private static final String TABLE = "credentials";
        private static final String COL_USER = "username";
        private static final String COL_PASS = "password";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + CredentialTable.TABLE + " (" + CredentialTable.COL_USER + " text, " + CredentialTable.COL_PASS + " text)" );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + CredentialTable.TABLE);
        onCreate(db);
    }

    // Add a new user
    public void addCredentials(String user, String pass) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(CredentialTable.COL_USER, user);
        values.put(CredentialTable.COL_PASS, pass);
        db.insert(CredentialTable.TABLE, null, values);
    }

    // Retrieve the hashed password for a user
    public String getPassword(String user) {
        SQLiteDatabase db = getReadableDatabase();
        String password = ""; // Holds the hashed password value

        // Get the row for a particular user
        String query = "select * from " + CredentialTable.TABLE + " where username = ?";
        Cursor cursor = db.rawQuery(query,new String[] { user });

       // Get the password for the user
        if(cursor.moveToFirst()) {
            do {
                password = cursor.getString(1);
            } while(cursor.moveToNext());
        }

        cursor.close();
        return password;
    }
}
