// Mike Shunk
// SNHU CS 360
// June 16, 2022
// Project Three
// LoginActivity.java
// This class creates the layout for our login screen and handles clicks on the "Login"
// and "Register" buttons.
package com.snhu.mikeshunkcs360projecttwo;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class LoginActivity extends AppCompatActivity {
    // Database for storing login credentials
    CredentialDatabase dbHelper = new CredentialDatabase(this);
    // Views for the elements of the activity
    EditText username;
    EditText password;
    TextView errorText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        // Hides the action bar
        getSupportActionBar().hide();
    }

    // Handles clicks on the "Login" button
    public void onClick(View view) {
        username = findViewById(R.id.editTextUsername);
        password = findViewById(R.id.editTextPassword);
        errorText = findViewById(R.id.errorText);

        // Gets the username and password from the text boxes and hash the password
        String user = username.getText().toString();
        String pass = getHashedPassword(password.getText().toString());

        // Get the hashed password for this user from the database
        String hashedPass = dbHelper.getPassword(user);

        // If the value of the entered, hashed password matches the stored hashed password,
        // start our main activity, otherwise, display an error message
        if(pass.equals(hashedPass)) {
            // Start GridActivity, our main screen
            Intent intent = new Intent(LoginActivity.this, GridActivity.class);
            startActivity(intent);
            // Finish this activity so that the 'back' button does not take us back to the login
            this.finish();
        }
        else {
            errorText.setText("Invalid Credentials!");
        }
    }

    // Handles clicks on the "Register" button
    public void onRegisterClick(View view) {
        username = findViewById(R.id.editTextUsername);
        password = findViewById(R.id.editTextPassword);
        errorText = findViewById(R.id.errorText);

        // Gets the username and password from the text boxes
        String user = username.getText().toString();
        String pass = password.getText().toString();

        // If the username and password fields are not empty (display error if so),
        // check if the username already exists (display error if so), and if not, add the
        // login credentials to the database
        if (!pass.matches("") && !user.matches("")) {
            String credentials = dbHelper.getPassword(user);
            if (credentials == "") {
                dbHelper.addCredentials(user, getHashedPassword(pass));
                // Start GridActivity, our main screen
                Intent intent = new Intent(LoginActivity.this, GridActivity.class);
                startActivity(intent);
                // Finish this activity so that the 'back' button does not take us back to the login
                this.finish();
            }
            else {
                errorText.setText("Username already exists!");
            }
        }
        else {
            errorText.setText("Username and password cannot be empty!");
        }
    }

    // Returns a hashed password using the SHA-256 algorithm
    private String getHashedPassword(String password) {
        // Stores the hashed password
        String hashedPass = null;

        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            // Hash the password
            byte[] bytes = md.digest(password.getBytes());
            // Converts byte array to a hexidecimal string
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < bytes.length; ++i) {
                sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
            }
            hashedPass = sb.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return hashedPass;
    }
}