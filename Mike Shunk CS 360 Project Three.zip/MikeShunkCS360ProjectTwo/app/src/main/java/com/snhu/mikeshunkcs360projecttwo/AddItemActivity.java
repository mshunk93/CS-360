// Mike Shunk
// SNHU CS 360
// June 16, 2022
// Project Three
// AddItemActivity.java
// This class creates the layout for our new item screen and handles clicks on the "Add" button.

package com.snhu.mikeshunkcs360projecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class AddItemActivity extends AppCompatActivity {

    // Views for the "add item" screen
    EditText itemName;
    EditText itemSku;
    EditText itemQty;
    EditText itemLoc;
    TextView errorText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);
    }

    // Called when user adds clicks "Add"
    public void onClick(View view) {
        itemName = findViewById(R.id.editTextItemName);
        itemSku = findViewById(R.id.editTextSku);
        itemQty = findViewById(R.id.editTextItemQuantity);
        itemLoc = findViewById(R.id.editTextItemLocation);
        errorText = findViewById(R.id.errorAddItem);

        ArrayList<String> item = new ArrayList<>(); // Stores the attributes of the new item

        // Gets the text from the views
        String name = itemName.getText().toString();
        String sku = itemSku.getText().toString();
        String qty = itemQty.getText().toString();
        String loc = itemLoc.getText().toString();

        // If any of the fields are empty, display an error message
        if(name.matches("") || sku.matches("") || qty.matches("") || loc.matches("") ) {
            errorText.setText("Please fill out all fields!");
        }
        else {
            item.add(name);
            item.add(sku);
            item.add(qty);
            item.add(loc);
            // Return to GridActivity and return an array list with our item attributes
            Intent intent = new Intent();
            intent.putExtra("new_item", item);
            setResult(RESULT_OK, intent);
            this.finish();
        }
    }
}
