// Mike Shunk
// SNHU CS 360
// June 16, 2022
// Project Three
// GridActivity.java
// This class creates a grid view with an app bar.
// There are also functions for handling clicks on an item, as well as the "alert" and "add" buttons
package com.snhu.mikeshunkcs360projecttwo;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class GridActivity extends AppCompatActivity implements GridAdapter.ItemClickListener {

    // String defining the permissions our app requests
    private String[] permissions = new String[]{Manifest.permission.SEND_SMS};
    // Database for storing inventory items
    private ItemDatabase items = new ItemDatabase(this);
    // An array of item objects
    private ArrayList<Item> itemsList;
    // View to display our item cards
    RecyclerView itemGrid;
    private LinearLayoutManager linearLayoutManager;
    private GridAdapter gridAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid);

        // Request permission to sens SMS messages
        ActivityCompat.requestPermissions(GridActivity.this, permissions,100 );

        itemGrid = findViewById(R.id.itemGrid);

        /* Uncomment to initialize some items
        items.addItem("Coca-Cola", 657489, 59, "Aisle 1, Bay 5, Shelf 5");
        items.addItem("Pepsi", 486751, 75, "Aisle 2, Bay 7, Shelf 15");
        items.addItem("Nacho Doritos", 453987, 29, "Aisle 13, Bay 4, Shelf 7");
        items.addItem("Tostito's Salsa", 198576, 24, "Aisle 4, Bay 5, Shelf 2");
        items.addItem("Trail Mix", 587655, 43, "Aisle 5, Bay 2, Shelf 14");
        items.addItem("Granola Bars", 485267, 12, "Aisle 12, Bay 1, Shelf 6");
        items.addItem("Bottled Water", 154789, 21, "Aisle 14, Bay 9, Shelf 3");
        items.addItem("Gatorade", 115988, 48, "Aisle 7, Bay 5, Shelf 4");
        items.addItem("Ground Coffee", 646594, 10, "Aisle 3, Bay 12, Shelf 16");
        items.addItem("Coors Banquet Beer", 147598, 24, "Aisle 3, Bay 4, Shelf 6");
        */

        // Get all of the items from the item database
        itemsList = items.getAllItems();

        // Setup the adapter for our recycler view
        gridAdapter = new GridAdapter(this, itemsList);
        gridAdapter.setClickListener(this);
        itemGrid.setAdapter(gridAdapter);

        // Setup the layout manager for our recycler view
        linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        itemGrid.setLayoutManager(linearLayoutManager);
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    // Inflate the app bar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.appbar_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    // Start the alert activity when the "alert" icon is pressed
    public void onAlertClick(MenuItem item) {
        Intent intent = new Intent(GridActivity.this, AlertActivity.class);
        startActivity(intent);
    }

    // Start the add item activity the the "+" floating action button is pressed
    public void onAddItemClick(View view) {
        Intent intent = new Intent(GridActivity.this, AddItemActivity.class);
        startActivityForResult(intent, 0);
    }

    // Handles the results of the "add item" and "edit item" activities
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Add a new item to our items database
        if(resultCode == RESULT_OK && requestCode == 0) {
            ArrayList<String> newItem = data.getStringArrayListExtra("new_item");
            items.addItem(newItem.get(0), Integer.parseInt(newItem.get(1)), Integer.parseInt(newItem.get(2)), newItem.get(3) );
        }

        // Update an item in our database
        if(resultCode == RESULT_OK && requestCode == 1) {
            items.updateItem(data.getStringArrayListExtra("edit_item"));
        }

        // Update our list of items and recreate the view appropriately
        itemsList = items.getAllItems();
        recreate();
    }

    // Handles clicks on an item card
    @Override
    public void onItemClick(View view, int position) {
        // Gets the view at the selected position in our recycler view
        View itemView = linearLayoutManager.findViewByPosition(position);
        // Views for the item attributes
        TextView itemName, itemSku, itemQty,itemLoc;
        // An array list for storing attributes of an item
        ArrayList<String> item = new ArrayList<>();

        itemName = itemView.findViewById(R.id.itemName);
        itemSku = itemView.findViewById(R.id.itemSku);
        itemQty = itemView.findViewById(R.id.itemQty);
        itemLoc = itemView.findViewById(R.id.itemLoc);

        // Add the attributes of the selected items to the array list, removing the labels
        item.add(itemName.getText().toString());
        String sku = itemSku.getText().toString().substring(5);
        item.add(sku);
        item.add(itemQty.getText().toString().substring(5));
        item.add(itemLoc.getText().toString().substring(10));

        // If the "delete" icon was clicked, delete the item from the database and refresh the
        // array list of items
        if(view.getId() == R.id.deleteImage){
            items.deleteItem(sku);
            itemsList = items.getAllItems();
        }

        // If the "edit" icon was pressed, start the "edit item" activity and put the array of
        // item attributes as an extra
        if(view.getId() == R.id.editImage) {
            Intent intent = new Intent(GridActivity.this, EditItemActivity.class);
            intent.putExtra("item", item);
            startActivityForResult(intent, 1);
        }

        // Let the adapter know its data set has been changed
        gridAdapter.notifyDataSetChanged();
    }
}