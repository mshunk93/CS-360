// Mike Shunk
// SNHU CS 360
// June 16, 2022
// Project Three
// GridAdapter.java
// This class is an adapter to populate our recycler view with item cards, as well as
// handle clicks on those cards' icons.
package com.snhu.mikeshunkcs360projecttwo;

import android.content.Context;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class GridAdapter extends RecyclerView.Adapter<GridAdapter.Viewholder> {

    private ArrayList<Item> itemArrayList;
    private ItemClickListener clickListener;

    // Constructor
    public GridAdapter(Context context, ArrayList<Item> itemArrayList) {
        this.itemArrayList = itemArrayList;
    }

    @NonNull
    @Override
    public GridAdapter.Viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // to inflate the layout for each item of recycler view.
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_item, parent, false);
        return new Viewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull GridAdapter.Viewholder holder, int position) {
        // to set data to textview of each card layout
        Item item = itemArrayList.get(position);

        holder.itemName.setText(item.getItemName());
        holder.itemSku.setText("SKU: " + String.valueOf(item.getItemSKU()));
        holder.itemQty.setText("Qty: " + String.valueOf(item.getItemQuantity()));
        holder.itemLoc.setText("Location: " + item.getItemLocation());

    }

    // this method is used for showing number of card items in recycler view.
    @Override
    public int getItemCount() {
        return itemArrayList.size();
    }

    // View holder class for initializing text views and image views on our item cards.
    public class Viewholder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private TextView itemName, itemSku, itemQty, itemLoc;
        private ImageView delete, edit;

        // Constructor
        public Viewholder(@NonNull View itemView) {
            super(itemView);

            itemName = itemView.findViewById(R.id.itemName);
            itemSku = itemView.findViewById(R.id.itemSku);
            itemQty = itemView.findViewById(R.id.itemQty);
            itemLoc = itemView.findViewById(R.id.itemLoc);
            delete = itemView.findViewById(R.id.deleteImage);
            edit = itemView.findViewById(R.id.editImage);

            // Set listeners for the "delete" and "edit" icons
            delete.setOnClickListener(this);
            edit.setOnClickListener(this);
        }

        // Handle clicks on the "delete" and "edit" icons
        @Override
        public void onClick(View view) {
            if (clickListener != null) {
                int pos = getAdapterPosition();

                // Call the "on click" implementation in the parent activity
                clickListener.onItemClick(view, pos);

                // If the "delete" icon was clicked, remove the item from the list of items
                // and notify the adapter that the it has been removed and the array size has changed
                if(view.getId() == R.id.deleteImage){
                    itemArrayList.remove(pos);
                    notifyItemRemoved(pos);
                    notifyItemRangeChanged(pos, itemArrayList.size());
                }

                // If the "edit" icon was clicked, notify the adapter that its data set has been changed
                if(view.getId() == R.id.editImage) {
                    notifyDataSetChanged();
                }
            }
        }
    }

    // Allows click events to be caught
    void setClickListener(ItemClickListener itemClickListener) {
        this.clickListener = itemClickListener;
    }

    // Set the implementation for the parent activity
    public interface ItemClickListener {
        void onItemClick(View view, int position);
    }
}

