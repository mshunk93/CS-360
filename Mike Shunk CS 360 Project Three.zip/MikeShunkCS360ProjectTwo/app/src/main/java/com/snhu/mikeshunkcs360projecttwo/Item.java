// Mike Shunk
// SNHU CS 360
// June 16, 2022
// Project Two
// Item.java
// This class defines an object for an inventory item

package com.snhu.mikeshunkcs360projecttwo;

public class Item {

    // Attributes of an Item
    private String itemName;
    private int itemSKU;
    private int itemQuantity;
    private String itemLocation;

    // Constructor
    public Item(String name, int sku, int qty, String loc) {
        this.itemName = name;
        this.itemSKU = sku;
        this.itemQuantity = qty;
        this.itemLocation = loc;
    }

    // Getters
    public String getItemName() {
        return itemName;
    }

    public int getItemSKU() {
        return itemSKU;
    }

    public int getItemQuantity() {
        return itemQuantity;
    }

    public String getItemLocation() {
        return itemLocation;
    }

    //Setters
    public void setItemName(String name) {
        this.itemName = name;
    }

    public void setItemSKU(int sku) {
        this.itemSKU = sku;
    }

    public void setItemQuantity(int qty) {
        this.itemQuantity = qty;
    }

    public void setItemLocation(String loc) {
        this.itemLocation = loc;
    }
}
